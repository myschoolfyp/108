"use client";

import { useState, useEffect } from "react";
import { useSearchParams, useRouter } from "next/navigation";

export default function Profile() {
  const searchParams = useSearchParams();
  const router = useRouter();

  const [userType, setUserType] = useState<string | null>(null);
  const [userData, setUserData] = useState<{
    firstName: string;
    lastName: string;
    email: string;
    contactNumber: string;
    profilePicture: string;
    userType: string;
    department?: string;
    cnic?: string; // Add CNIC for Admins, Teachers, and Parents
    rollNo?: string; // Add Roll No for Students
    classLevel?: string; // Add Class Level for Students
    classType?: string; // Add Class Type for Students
  } | null>(null);
  
  const [error, setError] = useState("");
  const [isMenuVisible, setIsMenuVisible] = useState(false);

  // In useEffect:
  useEffect(() => {
    const userTypeParam = searchParams.get("userType");
    const identifier = userTypeParam === "Student" 
      ? localStorage.getItem("rollNo")
      : localStorage.getItem("cnic");
    
    if (userTypeParam && identifier) {
      setUserType(userTypeParam);
      fetchUserData(identifier, userTypeParam);
    } else {
      setError("Please login first");
    }
  }, [searchParams]);

  // Modified fetchUserData:
  const fetchUserData = async (identifier: string, userType: string) => {
    try {
      const response = await fetch("/api/profile", {
        headers: { 
          identifier,
          userType 
        },
      });
      const data = await response.json();
      data.message ? setError(data.message) : setUserData(data);
    } catch (err) {
      setError("Failed to fetch user details");
    }
  };

  const handleLogout = () => {
    localStorage.removeItem("cnic");
    localStorage.removeItem("rollNo"); // Clear rollNo for Students
    router.push("/Components/Login");
  };

  if (error) return <div className="text-red-500 text-center mt-10">{error}</div>;
  if (!userData) return <div className="text-center mt-10 text-xl">Loading...</div>;

  return (
    <div className="flex bg-gray-50 min-h-screen">
      {/* Sidebar Navigation */}
      {isMenuVisible && (
  <nav className="fixed inset-y-0 left-0 w-64 bg-white text-[#0F6466] shadow-xl flex flex-col justify-between">
    <div>
      <div className="py-6 text-center font-bold text-2xl border-b border-[#0F6466]">
        Dashboard
      </div>
      {/* Show full navigation only for Admin */}
      {userData?.userType === "Admin" && (
        <div className="flex flex-col space-y-5 p-6">
          {/* First Section: Admins, Teachers, Students, Parents */}
          <div className="space-y-5">
            <button
              className="w-full py-3 px-5 rounded-lg bg-[#0F6466] text-white font-medium hover:bg-[#0D4B4C] transition duration-200 shadow-md"
              onClick={() => router.push("/Components/A/Admins")}
            >
              Admins
            </button>
            <button
              className="w-full py-3 px-5 rounded-lg bg-[#0F6466] text-white font-medium hover:bg-[#0D4B4C] transition duration-200 shadow-md"
              onClick={() => router.push("/Components/A/Teachers")}
            >
              Teachers
            </button>
            <button
              className="w-full py-3 px-5 rounded-lg bg-[#0F6466] text-white font-medium hover:bg-[#0D4B4C] transition duration-200 shadow-md"
              onClick={() => router.push("/Components/A/Students")}
            >
              Students
            </button>
            <button
              className="w-full py-3 px-5 rounded-lg bg-[#0F6466] text-white font-medium hover:bg-[#0D4B4C] transition duration-200 shadow-md"
              onClick={() => router.push("/Components/A/Parents")}
            >
              Parents
            </button>
          </div>

          {/* Second Section: Classes, Courses, Teachers, Timetable */}
          <div className="space-y-5 mt-4 border-t-2 border-[#0F6466] pt-4">
            <button
              className="w-full py-3 px-5 rounded-lg bg-[#0F6466] text-white font-medium hover:bg-[#0D4B4C] transition duration-200 shadow-md"
              onClick={() => router.push("/Components/A/Classes")}
            >
              Classes
            </button>
            <button
              className="w-full py-3 px-5 rounded-lg bg-[#0F6466] text-white font-medium hover:bg-[#0D4B4C] transition duration-200 shadow-md"
              onClick={() => router.push("/Components/A/Courses")}
            >
              Courses
            </button>
            
            <button
              className="w-full py-3 px-5 rounded-lg bg-[#0F6466] text-white font-medium hover:bg-[#0D4B4C] transition duration-200 shadow-md"
            >
              Timetable
            </button>
          </div>
        </div>
      )}
    </div>

    {/* Logout Button */}
    <div className="p-6">
      <button
        className="w-full py-3 rounded-lg bg-red-500 text-white font-medium hover:bg-red-600 transition duration-200 shadow-md"
        onClick={handleLogout}
      >
        Logout
      </button>
    </div>
  </nav>
)}
  
      {/* Main Content */}
      <main className={`flex-grow p-8 transition-all duration-300 ${isMenuVisible ? "ml-64" : "ml-0"}`}>
        <section className="mb-12 p-8 rounded-xl shadow-lg bg-white border border-[#0F6466]">
          <div className="flex justify-between items-center mb-6">
            {/* Menu Toggle Button */}
            <button
              className="flex items-center justify-center w-10 h-10 bg-[#0F6466] text-white rounded-full shadow-lg transition duration-200 hover:bg-[#0D4B4C]"
              onClick={() => setIsMenuVisible(!isMenuVisible)}
            >
              {isMenuVisible ? "✕" : "☰"}
            </button>
            {/* Edit Profile Button */}
            <button
              className="py-3 px-6 rounded-lg bg-[#0F6466] text-white font-medium hover:bg-[#0D4B4C] transition duration-200 shadow-md"
              onClick={() => router.push("/Editprofile")}
            >
              Edit Profile
            </button>
          </div>
  
          {/* Profile Details */}
          <div className="flex flex-col md:flex-row items-center gap-6">
            <div className="flex-shrink-0">
              <img
                src={userData.profilePicture}
                alt="Profile"
                className="w-40 h-40 rounded-full border-4 border-[#0F6466] shadow-xl"
              />
            </div>
            <div className="flex flex-col space-y-4 w-full">
              <h2 className="text-3xl font-bold text-[#0F6466]">
                {userData.firstName} {userData.lastName}
              </h2>
              <div className="mt-4 grid grid-cols-1 md:grid-cols-2 gap-4">
                {/* Contact Number */}
                <div className="p-4 bg-gray-100 rounded-lg">
                  <p className="text-lg">
                    <span className="font-semibold text-[#0F6466]">Contact:</span> {userData.contactNumber}
                  </p>
                </div>
  
                {/* Role */}
                <div className="p-4 bg-gray-100 rounded-lg">
                  <p className="text-lg">
                    <span className="font-semibold text-[#0F6466]">Role:</span> {userData.userType}
                  </p>
                </div>
  
                {/* CNIC for Admins, Teachers, and Parents */}
                {(userData.userType === "Admin" || userData.userType === "Teacher" || userData.userType === "Parent") && (
                  <div className="p-4 bg-gray-100 rounded-lg">
                    <p className="text-lg">
                      <span className="font-semibold text-[#0F6466]">CNIC:</span> {userData.cnic}
                    </p>
                  </div>
                )}
  
                {/* Roll No for Students */}
                {userData.userType === "Student" && (
                  <div className="p-4 bg-gray-100 rounded-lg">
                    <p className="text-lg">
                      <span className="font-semibold text-[#0F6466]">Roll No:</span> {userData.rollNo}
                    </p>
                  </div>
                )}
  
                {/* Department for Teachers */}
                {userData.userType === "Teacher" && userData.department && (
                  <div className="p-4 bg-gray-100 rounded-lg col-span-full">
                    <p className="text-lg">
                      <span className="font-semibold text-[#0F6466]">Department:</span> {userData.department}
                    </p>
                  </div>
                )}
  
                {/* Class Level and Class Type for Students */}
                {userData.userType === "Student" && (
                  <>
                    <div className="p-4 bg-gray-100 rounded-lg">
                      <p className="text-lg">
                        <span className="font-semibold text-[#0F6466]">Class Level:</span> {userData.classLevel}
                      </p>
                    </div>
                    <div className="p-4 bg-gray-100 rounded-lg">
                      <p className="text-lg">
                        <span className="font-semibold text-[#0F6466]">Class Type:</span> {userData.classType}
                      </p>
                    </div>
                  </>
                )}
              </div>
            </div>
          </div>
        </section>
  
        {/* Dashboard Title */}
        <h2 className="text-center text-5xl font-bold text-[#0F6466] mt-10">
          School Management Dashboard
        </h2>
      </main>
    </div>
  );
}